using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.AOVRecorder.Editor")]
